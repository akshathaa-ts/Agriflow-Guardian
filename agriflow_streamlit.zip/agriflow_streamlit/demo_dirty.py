"""Optional demo helper: makes a deliberately DIRTY copy of the dataset (pandas + numpy only).

The original Kaggle file is already clean, so the cleaning step has nothing to fix. This adds
SYNTHETIC problems to a copy - blank / N/A / ? / null cells, units inside numbers, misspelled labels,
impossible values, an extreme outlier and duplicate rows - so you can watch the cleaning code work.
Nothing here is real data.
"""
import numpy as np
import pandas as pd

NUM = ["Farm_Area(acres)", "Fertilizer_Used(tons)", "Pesticide_Used(kg)", "Yield(tons)", "Water_Usage(cubic meters)"]
CAT = ["Crop_Type", "Irrigation_Type", "Soil_Type", "Season"]


def make_dirty(raw: pd.DataFrame, seed: int = 7) -> pd.DataFrame:
    """Return a messy copy of `raw` (all columns as text). Works for the original Kaggle column names."""
    rng = np.random.default_rng(seed)
    d = raw.astype(str).copy()
    n = len(d)

    def pick(k):
        return rng.choice(n, min(k, n), replace=False)

    for i in pick(8):                                   # units inside numbers
        d.loc[i, "Farm_Area(acres)"] = d.loc[i, "Farm_Area(acres)"] + " acres"
    for i in pick(6):                                   # thousands separators
        try:
            d.loc[i, "Water_Usage(cubic meters)"] = "{:,}".format(int(float(d.loc[i, "Water_Usage(cubic meters)"])))
        except ValueError:
            pass
    typos = {"Cotton": "Cottn", "Barley": "barley ", "Tomato": "TOMATO", "Wheat": "Whaet", "Rice": "rice", "Potato": "Potatoe"}
    for i in pick(8):                                   # crop name typos / casing
        v = d.loc[i, "Crop_Type"]
        d.loc[i, "Crop_Type"] = typos.get(v, v.lower())
    for i in pick(4):
        v = d.loc[i, "Irrigation_Type"]
        d.loc[i, "Irrigation_Type"] = "Rain fed" if v == "Rain-fed" else v.upper()
    for i in pick(4):
        d.loc[i, "Soil_Type"] = d.loc[i, "Soil_Type"].lower() + " "
    for i in pick(2):                                   # impossible / extreme values
        d.loc[i, "Yield(tons)"] = rng.choice(["-12.5", "9999"])
    for i in pick(2):
        d.loc[i, "Water_Usage(cubic meters)"] = "-500"
    for i in pick(2):
        d.loc[i, "Farm_Area(acres)"] = "0"
    for c in NUM + CAT:                                 # missing values in several spellings
        for i in pick(3):
            d.loc[i, c] = rng.choice(["", "N/A", "?", "null", "-"])
    d = pd.concat([d, d.sample(min(3, n), random_state=1)])   # duplicate rows
    return d.sample(frac=1, random_state=3).reset_index(drop=True)
