"""Data cleaning for the AgriFlow Guardian agriculture dataset (pandas + numpy only).

Built for the Kaggle file with columns:
Farm_ID, Crop_Type, Farm_Area(acres), Irrigation_Type, Fertilizer_Used(tons), Pesticide_Used(kg),
Yield(tons), Soil_Type, Season, Water_Usage(cubic meters)
but tolerant of messy variants: blanks / 'N/A' / '?', units inside numbers, label typos,
impossible values, outliers and duplicates.
"""
from __future__ import annotations

import difflib
import re

import numpy as np
import pandas as pd

ALIASES = {
    "Farm_ID": ["farm_id", "farm", "id", "field_id"],
    "Crop_Type": ["crop_type", "crop", "crop_name"],
    "Farm_Area": ["farm_area_acres", "farm_area", "area", "area_acres", "land_area"],
    "Irrigation_Type": ["irrigation_type", "irrigation", "irrigation_method"],
    "Fertilizer_tons": ["fertilizer_used_tons", "fertilizer_used", "fertilizer", "fertilizer_tons"],
    "Pesticide_kg": ["pesticide_used_kg", "pesticide_used", "pesticide", "pesticide_kg"],
    "Yield_tons": ["yield_tons", "yield", "crop_yield", "production"],
    "Soil_Type": ["soil_type", "soil"],
    "Season": ["season", "crop_season"],
    "Water_m3": ["water_usage_cubic_meters", "water_usage", "water_used", "water_m3", "water"],
}
NUMERIC = ["Farm_Area", "Fertilizer_tons", "Pesticide_kg", "Yield_tons", "Water_m3"]
CATEGORICAL = ["Crop_Type", "Irrigation_Type", "Soil_Type", "Season"]

# Physically plausible ranges; values outside are entry/sensor errors -> NaN -> imputed.
VALID_RANGE = {
    "Farm_Area": (0.01, 100000), "Fertilizer_tons": (0, 1000), "Pesticide_kg": (0, 10000),
    "Yield_tons": (0, 10000), "Water_m3": (0, 10_000_000),
}
MISSING_TOKENS = {"", "na", "n/a", "nan", "null", "none", "?", "-", "--", "missing", "unknown", "#n/a", "nil"}


def _norm(name):
    return re.sub(r"[^a-z0-9]+", "_", str(name).strip().lower()).strip("_")


def _map_columns(df, log):
    lookup = {_norm(c): c for c in df.columns}
    rename = {}
    for target, aliases in ALIASES.items():
        for a in aliases:
            if a in lookup:
                rename[lookup[a]] = target
                break
    df = df.rename(columns=rename)
    absent = [c for c in ALIASES if c not in df.columns]
    msg = f"Mapped {len(rename)} of {len(ALIASES)} expected columns"
    log.append(msg + (f"; not found: {', '.join(absent)}" if absent else ""))
    return df


def _to_missing(s):
    """Turn sentinel strings ('N/A', '?', 'null', '') into real NaN."""
    s = s.astype("object")
    txt = s.astype(str).str.strip().str.lower()
    return s.where(~txt.isin(MISSING_TOKENS) & s.notna(), np.nan)


def _to_number(s):
    """'12.5 acres' / '1,200' / '3.4t' -> float."""
    s = _to_missing(s)
    cleaned = s.where(s.isna(), s.astype(str).str.replace(r"[^0-9.\-]", "", regex=True))
    return pd.to_numeric(cleaned, errors="coerce")


def _fix_categories(s):
    """Trim / case-fold, then merge typos ('Whaet', 'Rain fed') into more frequent labels.

    Labels are processed from most to least frequent; a label joins an already-accepted label if it is
    the same text ignoring spaces/punctuation, or very similar (difflib). Otherwise it is kept as a genuine,
    rare category, so real categories such as a crop grown on only 3 farms are never swallowed.
    """
    s = _to_missing(s)
    low = s.where(s.isna(), s.astype(str).str.strip().str.lower().str.replace(r"\s+", " ", regex=True))
    counts = low.value_counts()
    if counts.empty:
        return s, 0
    squash = lambda t: re.sub(r"[^a-z0-9]", "", t)  # noqa: E731
    canon, mapping = [], {}
    for v in counts.index:  # value_counts is sorted by frequency
        m = [c for c in canon if squash(c) == squash(v)]
        if not m:
            m = difflib.get_close_matches(v, canon, n=1, cutoff=0.78)
        if m:
            mapping[v] = m[0]
        else:
            canon.append(v)
            mapping[v] = v
    out = low.map(mapping)
    out = out.where(out.isna(), out.astype(str).str.title())
    out = out.str.replace("Rain-Fed", "Rain-fed", regex=False)
    changed = int(((out != s.astype(object)) & out.notna() & s.notna()).sum())
    return out, changed


def clean(raw):
    """Return (clean_df, report). The report feeds the Data Quality tab."""
    log = []
    rep = {"rows_raw": len(raw), "cols_raw": raw.shape[1]}

    df = _map_columns(raw.copy(), log)
    df = df[[c for c in ALIASES if c in df.columns]].copy()
    rep["missing_before"] = {c: float(_to_missing(df[c]).isna().mean() * 100) for c in df.columns}

    # 1. duplicates
    before = len(df)
    df = df.drop_duplicates().reset_index(drop=True)
    rep["duplicates_removed"] = before - len(df)
    log.append(f"Removed {before - len(df)} exact duplicate rows")
    if "Farm_ID" in df:
        df["Farm_ID"] = _to_missing(df["Farm_ID"]).astype(str).str.strip().str.upper().replace("NAN", np.nan)
        dup_ids = int(df["Farm_ID"].dropna().duplicated().sum())
        rep["duplicate_ids"] = dup_ids
        log.append(f"Duplicate Farm_IDs with different values: {dup_ids} (kept)" if dup_ids else "All Farm_IDs are unique")

    # 2. categorical typos / casing
    rep["category_fixes"] = {}
    for c in [c for c in CATEGORICAL if c in df]:
        df[c], fixed = _fix_categories(df[c])
        rep["category_fixes"][c] = fixed
        log.append(f"{c}: standardised {fixed} misspelled / irregular labels" if fixed else f"{c}: labels already consistent")

    # 3. numeric parsing + impossible values
    rep["invalid_values"] = {}
    for c in [c for c in NUMERIC if c in df]:
        df[c] = _to_number(df[c])
        lo, hi = VALID_RANGE[c]
        bad = (df[c] < lo) | (df[c] > hi)
        rep["invalid_values"][c] = int(bad.sum())
        df.loc[bad, c] = np.nan
        if bad.sum():
            log.append(f"{c}: {int(bad.sum())} impossible values (outside {lo}..{hi}) set to missing")
    if not any(rep["invalid_values"].values()):
        log.append("No impossible numeric values found")

    # 4. extreme statistical outliers (beyond 3xIQR fence) are treated as entry errors -> imputed
    rep["outliers_capped"] = {}
    for c in [c for c in NUMERIC if c in df]:
        q1, q3 = df[c].quantile([.25, .75])
        iqr = q3 - q1
        lo, hi = q1 - 3 * iqr, q3 + 3 * iqr
        mask = (df[c] < lo) | (df[c] > hi)
        rep["outliers_capped"][c] = int(mask.sum())
        df.loc[mask, c] = np.nan
        if mask.sum():
            log.append(f"{c}: {int(mask.sum())} extreme outliers (beyond 3xIQR) treated as errors and re-estimated")

    # 5. imputation
    imputed = {}
    for c in [c for c in NUMERIC if c in df]:
        imputed[c] = int(df[c].isna().sum())
        if "Crop_Type" in df:
            df[c] = df[c].fillna(df.groupby("Crop_Type")[c].transform("median"))
        df[c] = df[c].fillna(df[c].median())
    for c in [c for c in CATEGORICAL if c in df]:
        imputed[c] = int(df[c].isna().sum())
        mode = df[c].mode()
        df[c] = df[c].fillna(mode.iloc[0] if len(mode) else "Unknown")
    if "Farm_ID" in df:
        imputed["Farm_ID"] = int(df["Farm_ID"].isna().sum())
        miss = df["Farm_ID"].isna()
        df.loc[miss, "Farm_ID"] = [f"F-NEW{i:03d}" for i in range(1, miss.sum() + 1)]
    rep["imputed"] = imputed
    total = sum(imputed.values())
    log.append(f"Imputed {total} missing values (numeric: median per crop, then global median; categorical: most common label)"
               if total else "No missing values to impute")

    # 6. derived metrics
    if {"Farm_Area", "Yield_tons"} <= set(df.columns):
        df["Yield_per_Acre"] = (df["Yield_tons"] / df["Farm_Area"]).round(4)
        df["Farm_Size"] = pd.cut(df["Farm_Area"], [0, 100, 300, np.inf], labels=["Small (<100 ac)", "Medium (100-300 ac)", "Large (>300 ac)"])
    if {"Water_m3", "Yield_tons"} <= set(df.columns):
        df["Water_per_Ton"] = (df["Water_m3"] / df["Yield_tons"].clip(lower=0.1)).round(1)
    if {"Fertilizer_tons", "Farm_Area"} <= set(df.columns):
        df["Fertilizer_per_Acre_kg"] = (df["Fertilizer_tons"] * 1000 / df["Farm_Area"]).round(2)
    if "Season" in df:
        df["Season"] = pd.Categorical(df["Season"], [s for s in ["Kharif", "Rabi", "Zaid"] if s in set(df["Season"])]
                                      + [s for s in df["Season"].unique() if s not in ("Kharif", "Rabi", "Zaid")])

    rep["missing_after"] = {c: float(df[c].isna().mean() * 100) for c in rep["missing_before"] if c in df}
    rep["rows_clean"] = len(df)
    rep["log"] = log
    return df, rep
