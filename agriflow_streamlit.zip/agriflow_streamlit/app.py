"""AgriFlow Guardian - Streamlit dashboard (streamlit, pandas, numpy, matplotlib, seaborn).

Run:  python -m streamlit run app.py
"""
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import streamlit as st

import charts as C
import cleaning
from demo_dirty import make_dirty

DATA_FILE = Path(__file__).parent / "data" / "agriculture_dataset.csv"
PAGES = ["Overview", "Data Cleaning", "Crop Analysis", "Irrigation & Water", "Scatter Plots", "Correlation", "Data Explorer"]
FILTERS = [("Crop_Type", "Crop"), ("Irrigation_Type", "Irrigation"), ("Season", "Season"), ("Soil_Type", "Soil")]
NUM_LABELS = {"Farm_Area": "Farm area (acres)", "Fertilizer_tons": "Fertilizer (tons)", "Pesticide_kg": "Pesticide (kg)",
              "Yield_tons": "Yield (tons)", "Water_m3": "Water usage (m3)", "Yield_per_Acre": "Yield per acre",
              "Water_per_Ton": "Water per ton of yield"}

st.set_page_config(page_title="AgriFlow Guardian", page_icon="🌾", layout="wide")


# ------------------------------------------------------------------ data loading + cleaning (cached)
@st.cache_data(show_spinner="Reading and cleaning the data ...")
def load_and_clean(source: str, uploaded_bytes: bytes = b""):
    """Read the RAW csv as text (nothing is converted yet) and run it through cleaning.clean()."""
    if source == "Upload my own CSV" and uploaded_bytes:
        import io
        raw = pd.read_csv(io.BytesIO(uploaded_bytes), dtype=str, keep_default_na=False, encoding_errors="replace")
    else:
        raw = pd.read_csv(DATA_FILE, dtype=str, keep_default_na=False, encoding_errors="replace")
        if source == "Demo: dirty copy (synthetic errors)":
            raw = make_dirty(raw)
    clean_df, report = cleaning.clean(raw)
    return raw, clean_df, report


def show(fig, caption=None):
    """Display a matplotlib figure, then free its memory."""
    if fig is None:
        st.info("This chart needs a column that is not in the selected data.")
        return
    st.pyplot(fig, use_container_width=True)
    plt.close(fig)
    if caption:
        st.caption(caption)


def has(df, *cols):
    return all(c in df.columns for c in cols)


# ------------------------------------------------------------------ sidebar: navigation + data source + filters
st.sidebar.title("🌾 AgriFlow Guardian")
st.sidebar.caption("Smart farm analytics")
page = st.sidebar.radio("Navigation", PAGES)

st.sidebar.markdown("---")
st.sidebar.subheader("Data source")
source = st.sidebar.selectbox("Dataset", ["Original Kaggle file", "Demo: dirty copy (synthetic errors)", "Upload my own CSV"])
upload = None
if source == "Upload my own CSV":
    upload = st.sidebar.file_uploader("Raw CSV file", type=["csv"])
    if upload is None:
        st.sidebar.info("Upload a CSV, or the original file is used.")

raw, df_all, rep = load_and_clean(source, upload.getvalue() if upload is not None else b"")

st.sidebar.markdown("---")
st.sidebar.subheader("Filters")
mask = pd.Series(True, index=df_all.index)
for col, label in FILTERS:
    if col in df_all.columns:
        options = sorted(df_all[col].astype(str).unique())
        chosen = st.sidebar.multiselect(label, options, default=options)
        mask &= df_all[col].astype(str).isin(chosen)
df = df_all[mask].copy()
for col in df.select_dtypes("category").columns:        # drop unused categories after filtering
    df[col] = df[col].cat.remove_unused_categories()
st.sidebar.caption(f"{len(df):,} of {len(df_all):,} farms selected")

st.title(page)

if df.empty:
    st.warning("No farms match the current filters. Select at least one value in each filter.")
    st.stop()


# ------------------------------------------------------------------ PAGE: Overview
if page == "Overview":
    st.caption("Headline numbers and the big picture for the selected farms.")
    c = st.columns(5)
    c[0].metric("Farms", f"{len(df):,}")
    c[1].metric("Total area", f"{df['Farm_Area'].sum():,.0f} ac")
    c[2].metric("Avg yield", f"{df['Yield_tons'].mean():.1f} t")
    c[3].metric("Total water", f"{df['Water_m3'].sum() / 1e6:.2f} M m3")
    c[4].metric("Fertilizer", f"{df['Fertilizer_tons'].sum():,.0f} t")

    left, right = st.columns(2)
    with left:
        show(C.pie_share(df, "Crop_Type", "Share of farms by crop"), "Pie chart: how many farms grow each crop.")
    with right:
        show(C.pie_share(df, "Irrigation_Type", "Irrigation methods in use", donut=True), "Donut chart: irrigation method mix.")
    left, right = st.columns(2)
    with left:
        show(C.bar_mean(df, "Crop_Type", "Yield_tons", "Average yield by crop"))
    with right:
        show(C.scatter(df, "Water_m3", "Yield_tons", "Crop_Type", "Water usage vs yield"))

    best = df.groupby("Crop_Type", observed=True)["Yield_tons"].mean().sort_values(ascending=False)
    st.success(f"Highest average yield: **{best.index[0]}** ({best.iloc[0]:.1f} t). "
               f"Lowest: **{best.index[-1]}** ({best.iloc[-1]:.1f} t).")

# ------------------------------------------------------------------ PAGE: Data Cleaning
elif page == "Data Cleaning":
    st.caption("What was checked in the raw file and what the pandas cleaning code fixed.")
    c = st.columns(4)
    c[0].metric("Raw rows", f"{rep['rows_raw']:,}")
    c[1].metric("Clean rows", f"{rep['rows_clean']:,}")
    c[2].metric("Duplicates removed", f"{rep['duplicates_removed']:,}")
    c[3].metric("Cells imputed", f"{sum(rep['imputed'].values()):,}")

    if source == "Original Kaggle file":
        st.info("The original Kaggle file is already clean (no missing values, duplicates or impossible readings). "
                "Choose **Demo: dirty copy** in the sidebar to see the cleaning code fix synthetic errors.")
    elif source.startswith("Demo"):
        st.warning("This is a dirty copy with SYNTHETIC errors added for demonstration. It is not real data.")

    left, right = st.columns(2)
    with left:
        show(C.missing_compare(rep))
    with right:
        show(C.issues_bar(rep))

    cols = list(rep["missing_before"])
    summary = pd.DataFrame({
        "Column": cols,
        "Missing before (%)": [rep["missing_before"][k] for k in cols],
        "Missing after (%)": [rep["missing_after"].get(k, 0.0) for k in cols],
        "Impossible values": [rep["invalid_values"].get(k, 0) for k in cols],
        "Extreme outliers fixed": [rep["outliers_capped"].get(k, 0) for k in cols],
        "Label typos fixed": [rep["category_fixes"].get(k, 0) for k in cols],
    })
    st.subheader("Per-column quality summary")
    st.dataframe(summary, use_container_width=True, hide_index=True)

    st.subheader("Cleaning log")
    for line in rep["log"]:
        st.write("- " + line)

    with st.expander("Raw data (before cleaning, first 100 rows)"):
        st.dataframe(raw.head(100), use_container_width=True)
    with st.expander("How the cleaning works"):
        st.markdown(
            "1. Sentinel text (`''`, `N/A`, `?`, `null`, `-`) becomes real `NaN`\n"
            "2. Duplicate rows are dropped\n"
            "3. Labels are trimmed, case-folded and fuzzy-matched (`Cottn` -> `Cotton`) with `difflib`\n"
            "4. Units and commas are stripped from numbers (`329.4 acres` -> `329.4`) with `pd.to_numeric`\n"
            "5. Impossible values (negative yield, area 0) become `NaN`\n"
            "6. Extreme outliers (beyond 3 x IQR) are treated as entry errors\n"
            "7. Missing numbers get the median of their crop (then the overall median); missing labels get the most common label")

# ------------------------------------------------------------------ PAGE: Crop Analysis
elif page == "Crop Analysis":
    st.caption("How each crop performs.")
    left, right = st.columns(2)
    with left:
        show(C.bar_mean(df, "Crop_Type", "Yield_tons", "Average yield by crop (ranked)", horizontal=True))
    with right:
        show(C.box_strip(df, "Crop_Type", "Yield_tons", "Yield spread by crop"), "Box plot, one dot per farm.")
    left, right = st.columns(2)
    with left:
        show(C.bar_mean(df, "Crop_Type", "Water_m3", "Average water use by crop", horizontal=True, color=C.PAL[4], fmt="{:,.0f}"))
    with right:
        show(C.bubble(df, "Water_m3", "Yield_tons", "Farm_Area", "Crop_Type", "Crop efficiency (bubble size = farm area)"))
    show(C.heatmap_pivot(df, "Crop_Type", "Season", "Yield_tons", "Average yield: crop x season"),
         "Blank cells mean no farm has that crop-season combination.")

# ------------------------------------------------------------------ PAGE: Irrigation & Water
elif page == "Irrigation & Water":
    st.caption("How water is used and what it returns.")
    left, right = st.columns(2)
    with left:
        show(C.pie_share(df, "Irrigation_Type", "Farms by irrigation type"))
    with right:
        show(C.bar_mean(df, "Irrigation_Type", "Water_per_Ton", "Water needed per ton of yield (lower is better)",
                        color=C.PAL[5], fmt="{:,.0f}"))
    left, right = st.columns(2)
    with left:
        show(C.bar_mean(df, "Irrigation_Type", "Water_m3", "Average water use by irrigation type", color=C.PAL[4], fmt="{:,.0f}"))
    with right:
        show(C.bar_mean(df, "Irrigation_Type", "Yield_tons", "Average yield by irrigation type"))
    show(C.box_strip(df, "Irrigation_Type", "Yield_tons", "Yield spread by irrigation type"))
    if has(df, "Irrigation_Type", "Water_per_Ton"):
        eff = df.groupby("Irrigation_Type", observed=True)["Water_per_Ton"].median().sort_values()
        st.success(f"Most water-efficient method: **{eff.index[0]}** (median {eff.iloc[0]:,.0f} m3 per ton). "
                   f"Least efficient: **{eff.index[-1]}** ({eff.iloc[-1]:,.0f} m3 per ton).")

# ------------------------------------------------------------------ PAGE: Scatter Plots
elif page == "Scatter Plots":
    st.caption("Pick any two measures to see how they relate. The dashed line is the linear trend with its correlation r.")
    num_cols = [c for c in NUM_LABELS if c in df.columns]
    cat_cols = [c for c, _ in FILTERS if c in df.columns]
    a, b, c3 = st.columns(3)
    x = a.selectbox("X axis", num_cols, index=num_cols.index("Water_m3") if "Water_m3" in num_cols else 0,
                    format_func=lambda k: NUM_LABELS[k])
    y = b.selectbox("Y axis", num_cols, index=num_cols.index("Yield_tons") if "Yield_tons" in num_cols else 1,
                    format_func=lambda k: NUM_LABELS[k])
    hue = c3.selectbox("Colour by", cat_cols)
    if x == y:
        st.warning("Choose two different measures.")
    else:
        show(C.scatter(df, x, y, hue, f"{NUM_LABELS[y]} vs {NUM_LABELS[x]}"))
    st.markdown("#### Input use and yield")
    left, right = st.columns(2)
    with left:
        show(C.scatter(df, "Fertilizer_tons", "Yield_tons", "Crop_Type", "Fertilizer vs yield"))
    with right:
        show(C.scatter(df, "Farm_Area", "Yield_tons", "Crop_Type", "Farm area vs yield"))

# ------------------------------------------------------------------ PAGE: Correlation
elif page == "Correlation":
    st.caption("Which measures move together. Values near +1 or -1 are strong; near 0 means little linear relationship.")
    left, right = st.columns([3, 2])
    with left:
        show(C.heatmap_corr(df), "Blue = positive, orange = negative relationship.")
    with right:
        cols = [c for c in ["Farm_Area", "Fertilizer_tons", "Pesticide_kg", "Water_m3", "Yield_tons"] if c in df.columns]
        corr = df[cols].corr()
        pairs = (corr.where(np.tril(np.ones(corr.shape, dtype=bool), k=-1)).stack()
                 .rename("r").reset_index().rename(columns={"level_0": "Measure A", "level_1": "Measure B"}))
        pairs["abs"] = pairs["r"].abs()
        pairs = pairs.sort_values("abs", ascending=False).drop(columns="abs")
        st.subheader("Strongest relationships")
        st.dataframe(pairs.round(2), use_container_width=True, hide_index=True)
        if len(df) < 30:
            st.warning(f"Only {len(df)} farms are selected, so these correlations are rough guides.")
    show(C.pairplot(df))

# ------------------------------------------------------------------ PAGE: Data Explorer
elif page == "Data Explorer":
    st.caption("Search the cleaned records, view summary statistics and download the cleaned file.")
    q = st.text_input("Search (any column)", "")
    view = df.copy()
    for col in view.select_dtypes("category").columns:
        view[col] = view[col].astype(str)
    if q.strip():
        hit = view.astype(str).apply(lambda s: s.str.contains(q.strip(), case=False, regex=False)).any(axis=1)
        view = view[hit]
    st.write(f"**{len(view):,}** rows")
    st.dataframe(view, use_container_width=True, hide_index=True)
    st.download_button("Download cleaned CSV", view.to_csv(index=False).encode("utf-8"),
                       file_name="agriculture_clean.csv", mime="text/csv")
    st.subheader("Summary statistics")
    st.dataframe(df.select_dtypes("number").describe().T.round(2), use_container_width=True)
