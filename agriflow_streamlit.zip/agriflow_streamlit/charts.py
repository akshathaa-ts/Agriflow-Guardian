"""Matplotlib + Seaborn chart builders. Every builder returns a Figure (or None if columns are absent).
The Streamlit app shows them with st.pyplot(fig)."""
from __future__ import annotations

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import seaborn as sns  # noqa: E402

# Colour-blind-friendly palette (Okabe-Ito based), used in a fixed order.
PAL = ["#0072B2", "#E69F00", "#009E73", "#CC79A7", "#56B4E9", "#D55E00", "#7A7A7A", "#F0E442", "#332288", "#88CCEE"]
TEAL = "#2A9D8F"   # single-series colour (matches the dashboard theme)
INK, MUTED, GRID = "#1b2433", "#667085", "#e4e7ec"

sns.set_theme(style="whitegrid")
plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 10, "axes.edgecolor": GRID, "axes.labelcolor": MUTED,
    "axes.titlesize": 12, "axes.titleweight": "bold", "axes.titlecolor": INK, "axes.titlelocation": "left",
    "xtick.color": MUTED, "ytick.color": MUTED, "grid.color": GRID, "axes.spines.top": False,
    "axes.spines.right": False, "figure.facecolor": "white", "axes.facecolor": "white",
})

LABELS = {"Farm_Area": "Farm area (acres)", "Fertilizer_tons": "Fertilizer used (tons)", "Pesticide_kg": "Pesticide used (kg)",
          "Yield_tons": "Yield (tons)", "Water_m3": "Water usage (m³)", "Yield_per_Acre": "Yield per acre (tons)",
          "Water_per_Ton": "Water per ton of yield (m³)"}


def _has(df, *cols):
    return all(c in df.columns for c in cols)


def _order(df, cat, val):
    return df.groupby(cat, observed=True)[val].mean().sort_values(ascending=False).index.tolist()


def _pal(n):
    return (PAL * 3)[:n]


# ------------------------------------------------------------- PIE / DONUT
def pie_share(df, col, title, donut=False, weight=None):
    if not _has(df, col):
        return None
    s = df.groupby(col, observed=True)[weight].sum() if weight else df[col].value_counts()
    s = s[s > 0].sort_values(ascending=False)
    fig, ax = plt.subplots(figsize=(6.0, 4.6))
    wedges, _, _ = ax.pie(
        s.values, autopct=lambda p: f"{p:.0f}%" if p >= 5 else "", startangle=90, counterclock=False,
        colors=_pal(len(s)), pctdistance=0.78 if donut else 0.66,
        wedgeprops=dict(width=0.42 if donut else 1, edgecolor="white", linewidth=2),
        textprops=dict(color="white", fontsize=9, fontweight="bold"))
    lab = [f"{k}  ({v:,.0f})" for k, v in s.items()]
    ax.legend(wedges, lab, loc="center left", bbox_to_anchor=(1.0, .5), frameon=False)
    if donut:
        ax.text(0, 0, f"{s.sum():,.0f}\n{'total' if weight else 'farms'}", ha="center", va="center", fontsize=11,
                color=INK, fontweight="bold")
    ax.set_title(title)
    return fig


# ------------------------------------------------------------- BAR
def bar_mean(df, cat, val, title, horizontal=False, color=None, agg="mean", fmt="{:,.1f}"):
    if not _has(df, cat, val):
        return None
    g = df.groupby(cat, observed=True)[val].agg(agg).sort_values(ascending=False)
    fig, ax = plt.subplots(figsize=(6.6, 4.4))
    if horizontal:
        ax.barh(g.index.astype(str)[::-1], g.values[::-1], color=color or TEAL, height=.62)
        for i, v in enumerate(g.values[::-1]):
            ax.text(v, i, " " + fmt.format(v), va="center", fontsize=9, color=INK)
        ax.set_xlabel(LABELS.get(val, val)); ax.grid(axis="y", visible=False)
        ax.margins(x=.12)
    else:
        ax.bar(g.index.astype(str), g.values, color=color or TEAL, width=.62)
        for i, v in enumerate(g.values):
            ax.text(i, v, fmt.format(v), ha="center", va="bottom", fontsize=9, color=INK)
        ax.set_ylabel(LABELS.get(val, val)); ax.grid(axis="x", visible=False)
        plt.setp(ax.get_xticklabels(), rotation=25 if len(g) > 5 else 0, ha="right" if len(g) > 5 else "center")
        ax.margins(y=.12)
    ax.set_title(title)
    return fig


def bar_top_farms(df, val, title, n=10, ascending=False):
    if not _has(df, "Farm_ID", val):
        return None
    t = df.sort_values(val, ascending=ascending).head(n)
    fig, ax = plt.subplots(figsize=(6.6, 4.4))
    labels = (t["Farm_ID"].astype(str) + "  " + t["Crop_Type"].astype(str)) if "Crop_Type" in t else t["Farm_ID"].astype(str)
    ax.barh(labels[::-1], t[val][::-1], color=TEAL if not ascending else PAL[5], height=.62)
    for i, v in enumerate(t[val][::-1]):
        ax.text(v, i, f" {v:,.1f}", va="center", fontsize=9, color=INK)
    ax.set_title(title); ax.set_xlabel(LABELS.get(val, val)); ax.grid(axis="y", visible=False); ax.margins(x=.12)
    return fig


def bar_grouped(df, cat, hue, val, title):
    if not _has(df, cat, hue, val):
        return None
    fig, ax = plt.subplots(figsize=(7.4, 4.5))
    sns.barplot(data=df, x=cat, y=val, hue=hue, errorbar=None, palette=_pal(df[hue].nunique()), ax=ax, width=.8)
    ax.set_title(title); ax.set_ylabel(LABELS.get(val, val)); ax.set_xlabel("")
    ax.legend(frameon=False, title="", ncol=min(5, df[hue].nunique()), loc="upper center", bbox_to_anchor=(.5, -.12))
    plt.setp(ax.get_xticklabels(), rotation=25, ha="right")
    return fig


def bar_stacked_count(df, cat, hue, title):
    if not _has(df, cat, hue):
        return None
    ct = pd.crosstab(df[cat], df[hue])
    ct = ct.loc[ct.sum(axis=1).sort_values(ascending=False).index]
    fig, ax = plt.subplots(figsize=(6.8, 4.5))
    ct.plot(kind="bar", stacked=True, ax=ax, color=_pal(ct.shape[1]), width=.72, edgecolor="white", linewidth=1.5)
    ax.set_title(title); ax.set_ylabel("Number of farms"); ax.set_xlabel("")
    ax.legend(title="", frameon=False, ncol=ct.shape[1], loc="upper center", bbox_to_anchor=(.5, -.18))
    plt.setp(ax.get_xticklabels(), rotation=25, ha="right")
    return fig


# ------------------------------------------------------------- SCATTER / BUBBLE
def scatter(df, x, y, hue, title, trend=True):
    if not _has(df, x, y):
        return None
    fig, ax = plt.subplots(figsize=(6.8, 4.8))
    h = hue if hue in df.columns else None
    sns.scatterplot(data=df, x=x, y=y, hue=h, palette=_pal(df[h].nunique()) if h else None, s=62, alpha=.85,
                    edgecolor="white", linewidth=.8, ax=ax)
    if trend and len(df) > 2:
        m, b = np.polyfit(df[x], df[y], 1)
        xs = np.linspace(df[x].min(), df[x].max(), 50)
        r = df[[x, y]].corr().iloc[0, 1]
        ax.plot(xs, m * xs + b, color=INK, lw=2, ls="--", label=f"Trend (r = {r:.2f})")
    ax.set_title(title); ax.set_xlabel(LABELS.get(x, x)); ax.set_ylabel(LABELS.get(y, y))
    ax.legend(frameon=False, fontsize=8, title="", loc="best")
    return fig


def bubble(df, x, y, size, grp, title):
    if not _has(df, x, y, size, grp):
        return None
    g = df.groupby(grp, observed=True).agg(x=(x, "mean"), y=(y, "mean"), s=(size, "mean")).reset_index()
    fig, ax = plt.subplots(figsize=(6.8, 4.8))
    ax.scatter(g["x"], g["y"], s=(g["s"] / g["s"].max()) ** 2 * 1700, c=_pal(len(g)), alpha=.8, edgecolor="white", linewidth=2)
    for _, r in g.iterrows():
        ax.annotate(str(r[grp]), (r["x"], r["y"]), ha="center", va="center", fontsize=8.5, color=INK, fontweight="bold")
    ax.margins(.2); ax.set_title(title); ax.set_xlabel("Average " + LABELS.get(x, x).lower()); ax.set_ylabel("Average " + LABELS.get(y, y).lower())
    return fig


# ------------------------------------------------------------- DISTRIBUTIONS
def hist(df, col, title, color=None, bins=14):
    if not _has(df, col):
        return None
    fig, ax = plt.subplots(figsize=(6.4, 4.4))
    sns.histplot(df[col], bins=bins, kde=True, color=color or TEAL, edgecolor="white", alpha=.85, ax=ax)
    ax.axvline(df[col].mean(), color=INK, ls="--", lw=1.6, label=f"Mean {df[col].mean():,.1f}")
    ax.legend(frameon=False); ax.set_title(title); ax.set_xlabel(LABELS.get(col, col)); ax.set_ylabel("Farms")
    return fig


def box_strip(df, cat, val, title):
    if not _has(df, cat, val):
        return None
    order = _order(df, cat, val)
    fig, ax = plt.subplots(figsize=(7.0, 4.7))
    pal = _pal(len(order))
    sns.boxplot(data=df, x=cat, y=val, order=order, hue=cat, hue_order=order, palette=pal, legend=False, linewidth=1.2,
                fliersize=0, boxprops=dict(alpha=.55), ax=ax)
    sns.stripplot(data=df, x=cat, y=val, order=order, color=INK, size=3.6, alpha=.7, jitter=.18, ax=ax)
    ax.set_title(title); ax.set_xlabel(""); ax.set_ylabel(LABELS.get(val, val))
    plt.setp(ax.get_xticklabels(), rotation=25 if len(order) > 5 else 0, ha="right" if len(order) > 5 else "center")
    return fig


def violin(df, cat, val, title):
    if not _has(df, cat, val):
        return None
    order = _order(df, cat, val)
    fig, ax = plt.subplots(figsize=(7.0, 4.7))
    sns.violinplot(data=df, x=cat, y=val, order=order, hue=cat, hue_order=order, palette=_pal(len(order)), legend=False,
                   inner="quartile", linewidth=1, cut=0, ax=ax)
    ax.set_title(title); ax.set_xlabel(""); ax.set_ylabel(LABELS.get(val, val))
    return fig


# ------------------------------------------------------------- HEATMAPS / PAIR
def heatmap_corr(df, title="Correlation between farm metrics"):
    cols = [c for c in ["Farm_Area", "Fertilizer_tons", "Pesticide_kg", "Water_m3", "Yield_tons"] if c in df.columns]
    if len(cols) < 3:
        return None
    corr = df[cols].corr()
    mask = np.triu(np.ones_like(corr, dtype=bool), k=1)
    fig, ax = plt.subplots(figsize=(7.0, 5.4))
    sns.heatmap(corr, mask=mask, annot=True, fmt=".2f", cmap=sns.diverging_palette(35, 250, as_cmap=True, center="light"),
                vmin=-1, vmax=1, linewidths=2, linecolor="white", cbar_kws=dict(shrink=.8), ax=ax, annot_kws=dict(size=10))
    ax.set_title(title)
    ax.set_xticklabels([LABELS.get(c, c).split(" (")[0] for c in cols], rotation=30, ha="right")
    ax.set_yticklabels([LABELS.get(c, c).split(" (")[0] for c in cols], rotation=0)
    return fig


def heatmap_pivot(df, rows, cols, val, title, fmt=".1f"):
    if not _has(df, rows, cols, val):
        return None
    pv = df.pivot_table(index=rows, columns=cols, values=val, aggfunc="mean", observed=True)
    fig, ax = plt.subplots(figsize=(7.2, 5.0))
    sns.heatmap(pv, annot=True, fmt=fmt, cmap="YlGn", linewidths=2, linecolor="white", cbar_kws=dict(shrink=.8), ax=ax,
                annot_kws=dict(size=9))
    ax.set_title(title); ax.set_xlabel(""); ax.set_ylabel("")
    return fig


def pairplot(df, hue="Season"):
    cols = [c for c in ["Farm_Area", "Fertilizer_tons", "Water_m3", "Yield_tons"] if c in df.columns]
    if len(cols) < 3:
        return None
    d = df.copy()
    h = hue if hue in d.columns else None
    if h:
        d[h] = d[h].astype(str)
    g = sns.pairplot(d, vars=cols, hue=h, palette=_pal(d[h].nunique()) if h else None, corner=True,
                     plot_kws=dict(s=32, alpha=.8, edgecolor="white"), height=2.1)
    g.figure.suptitle(f"Pair plot of key metrics by {hue.lower()}", y=1.02, x=.05, ha="left", fontweight="bold", color=INK)
    return g.figure


# ------------------------------------------------------------- DATA QUALITY
def missing_compare(rep):
    b = pd.Series(rep["missing_before"]).sort_values(ascending=True)
    a = pd.Series(rep["missing_after"]).reindex(b.index).fillna(0)
    fig, ax = plt.subplots(figsize=(7, 4.6))
    y = np.arange(len(b))
    ax.barh(y + .2, b.values, height=.38, color=PAL[5], label="Before cleaning")
    ax.barh(y - .2, a.values, height=.38, color=PAL[2], label="After cleaning")
    ax.set_yticks(y); ax.set_yticklabels(b.index); ax.set_xlabel("Missing values (%)")
    ax.set_title("Missing data before vs after cleaning")
    ax.legend(frameon=False)
    if b.max() == 0:
        ax.text(.5, .5, "No missing values found in this file", transform=ax.transAxes, ha="center", fontsize=11, color=MUTED)
    return fig


def issues_bar(rep):
    items = {}
    for c, n in rep.get("invalid_values", {}).items():
        items[f"{c} impossible values"] = n
    for c, n in rep.get("outliers_capped", {}).items():
        items[f"{c} extreme outliers"] = n
    for c, n in rep.get("category_fixes", {}).items():
        items[f"{c} label typos"] = n
    items["Duplicate rows"] = rep.get("duplicates_removed", 0)
    s = pd.Series(items).sort_values()
    fig, ax = plt.subplots(figsize=(7, 5.2))
    s_nz = s[s > 0]
    if s_nz.empty:
        ax.axis("off")
        ax.text(.5, .5, "No errors detected in this file", ha="center", va="center", fontsize=13, color=MUTED)
    else:
        ax.barh(s_nz.index, s_nz.values, color=PAL[1], height=.62)
        for i, v in enumerate(s_nz.values):
            ax.text(v, i, f" {v:,}", va="center", fontsize=9, color=INK)
        ax.set_xlabel("Number of cells / rows")
    ax.set_title("Errors detected and fixed")
    return fig
