# AgriFlow Guardian - Streamlit Dashboard

Libraries: `streamlit`, `pandas`, `numpy`, `matplotlib`, `seaborn`.

## Run (VS Code terminal)

```
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

The dashboard opens at http://localhost:8501. (Use `python -m ...` instead of `pip` / `streamlit` directly -
it avoids PATH and blocked-.exe problems on Windows.)

## Navigation (sidebar)

Overview | Data Cleaning | Crop Analysis | Irrigation & Water | Scatter Plots | Correlation | Data Explorer

The sidebar also has a **Data source** switch and **filters** (crop, irrigation, season, soil) that apply to every page.

| Chart type | Where |
|---|---|
| Pie / donut | Overview, Irrigation & Water |
| Bar (vertical / horizontal) | Overview, Crop Analysis, Irrigation & Water |
| Scatter (+ trend line, interactive axes) | Overview, Scatter Plots |
| Correlation heatmap + pair plot | Correlation |
| Box, violin, bubble, histogram, pivot heatmap | Crop Analysis, Irrigation & Water |

## Data and cleaning

`data/agriculture_dataset.csv` is the original Kaggle file (50 farms). It is already clean, so the Data Cleaning
page reports "no errors". Pick **Demo: dirty copy** in the sidebar to see `cleaning.py` fix SYNTHETIC errors
(blank / N/A / ? cells, `329.4 acres`, `Cottn`, negative yield, duplicates). You can also upload any raw CSV with
similar columns.

`cleaning.py` (pandas + numpy): sentinel text -> NaN, duplicate removal, label typo fixing (difflib), unit
stripping with `pd.to_numeric`, impossible-value and 3xIQR outlier removal, median-per-crop imputation.

## Files

```
app.py            Streamlit app (navigation + pages)
cleaning.py       pandas cleaning pipeline
charts.py         matplotlib / seaborn chart functions
demo_dirty.py     makes the dirty demo copy
data/             original Kaggle CSV
requirements.txt
```
